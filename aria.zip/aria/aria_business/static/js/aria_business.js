document.addEventListener('DOMContentLoaded', function(){
    var nav = document.querySelector('nav');
    window.addEventListener('scroll', function(){
        if(window.pageYOffset > 100){
            nav.classList.add('navBgColor','shadow');
        }
        else{
            nav.classList.remove('navBgColor','shadow');
        }
    });

    const phoneCont = document.querySelector('.phoneHolder');
    const phone = document.querySelector('.phoneImg');
    phoneCont.addEventListener("mouseenter", (e) => {
        phone.style.transform = "translateZ(200px) rotateY(-45deg)";
    });
    phoneCont.addEventListener("mouseleave", (e) => {
        phone.style.transform = "translateZ(0px) rotateY(0deg)";
    });

});