
document.addEventListener("DOMContentLoaded", function(){
    toggleDashboard();
});
 function toggleDashboard(){
     const availableCustomers = document.querySelector(".availableCustomers");
     const CompanyProfile = document.querySelector(".CompanyProfile");
     const paymentSection = document.querySelector(".paymentSection");
    
     const available_customers = document.querySelector("#availableCustomers");
     const company_profile = document.querySelector("#CompanyProfile");
     const payment_section = document.querySelector("#paymentSection");

     company_profile.addEventListener('click', function(){
        available_customers.style.color = "black";
        company_profile.style.color = "red";
        payment_section.style.color = "black";
         if (CompanyProfile.classList.contains('d-none')){
            CompanyProfile.classList.remove('d-none');
            CompanyProfile.classList.add('d-block');
         }
         if (availableCustomers.classList.contains('d-block')){
            availableCustomers.classList.remove('d-block');
            availableCustomers.classList.add('d-none');
         }
         if (paymentSection.classList.contains('d-block')){
            paymentSection.classList.remove('d-block');
            paymentSection.classList.add('d-none');
         }
     });

     available_customers.addEventListener('click', function(){
         available_customers.style.color = "red";
         company_profile.style.color = "black";
         payment_section.style.color = "black";
        if (availableCustomers.classList.contains('d-none')){
            availableCustomers.classList.remove('d-none');
            availableCustomers.classList.add('d-block');
        }
        if (CompanyProfile.classList.contains('d-block')){
            CompanyProfile.classList.remove('d-block');
            CompanyProfile.classList.add('d-none');
        }
        if (paymentSection.classList.contains('d-block')){
           paymentSection.classList.remove('d-block');
           paymentSection.classList.add('d-none');
        }
    });

    payment_section.addEventListener('click', function(){
        available_customers.style.color = "black";
         company_profile.style.color = "black";
         payment_section.style.color = "red";
        if (paymentSection.classList.contains('d-none')){
            paymentSection.classList.remove('d-none');
            paymentSection.classList.add('d-block');
        }
        if (CompanyProfile.classList.contains('d-block')){
            CompanyProfile.classList.remove('d-block');
            CompanyProfile.classList.add('d-none');
        }
        if (availableCustomers.classList.contains('d-block')){
            availableCustomers.classList.remove('d-block');
            availableCustomers.classList.add('d-none');
        }
    });
 }
