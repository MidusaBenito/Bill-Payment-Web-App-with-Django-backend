from django.contrib import admin

from .models import *

@admin.register(Business_Profile)
class Business_ProfileAdmin(admin.ModelAdmin):
    #def first_name(self,user):
        #return user.user.first_name

    #def last_name(self,user):
        #return user.user.last_name

    list_display = ["user","business_id","business_name","business_website","location_state","administrator_first_name","administrator_last_name","administrator_job_title","phone_number","action","business_description","business_email"]
    #list_filter = ["account_type"]


def getFieldsModel(model):
    return [field.name for field in model._meta.get_fields()]


@admin.register(Business_Payment_Detail)
class Business_Payment_DetailAdmin(admin.ModelAdmin):
    list_display = getFieldsModel(Business_Payment_Detail)