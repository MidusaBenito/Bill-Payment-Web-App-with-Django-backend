from django.apps import AppConfig


class AriaBusinessConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aria_business'
