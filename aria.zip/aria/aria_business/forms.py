from . models import *
from django import forms
#from phonenumber_field.formfields import PhoneNumberField

class BusinessRegistrationForm(forms.ModelForm):
    class Meta:
        model = Business_Profile
        fields = ("business_name","business_website","location_state","administrator_first_name","administrator_last_name","administrator_job_title","phone_number","action","business_description","business_email")
        labels = {  "business_name":"Name of Business:",
                    "location_state": "Business Location (State):",
                    "business_website": "Website URL:",
                    "administrator_first_name": "Your First Name:",
                    "administrator_last_name":"Last First Name:",
                    "administrator_job_title":"Your Job Title:",
                    "business_email":"Email",
                    "phone_number":"Phone:",
                    "action":"What Would You Like to Do?",
                    "business_description":"Briefly Describe Your Business:",
                    }
        widgets = {
            "business_name":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"required","style":"height:2rem;"}),
            "location_state": forms.Select(attrs={"class":"form-select form-select-sm mt-1"}),
            "business_website":forms.TextInput(attrs={"class":"form-control mt-1","type":"url","placeholder":"required","style":"height:2rem;"}),
            "business_email": forms.EmailInput(attrs={"type":"email", "class":"form-control", "placeholder":"required","style":"height:2rem;"}),
            "administrator_first_name":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"required","style":"height:2rem;"}),
            "administrator_last_name":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"required","style":"height:2rem;"}),
            "administrator_job_title":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"required","style":"height:2rem;"}),
            "phone_number":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"required","style":"height:2rem;"}),
            "action": forms.Select(attrs={"class":"form-select form-select-sm mt-1"}),
            "business_description":forms.Textarea(attrs={"class":"form-control mt-1","type":"text","rows":"3"}),
        }
        


class BankPaymentDetailsForm(forms.ModelForm):
    class Meta:
        model = Business_Payment_Detail
        fields = ("account_number","official_name","routing")
        labels = {
            "account_number":"Account Number","official_name":"Account Holder Name","routing":"Account Routing Number",
        }
        widgets = {
            "account_number":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"Enter account holder name","style":"height:2rem;"}),
            "official_name":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"Account Number","style":"height:2rem;"}),
            "routing":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"Account Routing Number","style":"height:2rem;"}),
        }
