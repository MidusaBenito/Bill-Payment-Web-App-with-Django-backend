from django.db import models
from django.contrib.auth.models import User
#from phonenumber_field.modelfields import PhoneNumberField
from .utils import generateUsStates


class Business_Profile(models.Model):
    state_choices = generateUsStates()
    action_choices = [('Enroll','Enroll My Business'),('Enquiry','Learn More About Ariaquickpay'),('Reporting','Report an Issue Related to Ariaquickpay')]
    user = models.OneToOneField(User, null=True, unique=False, on_delete=models.CASCADE)
    business_id = models.CharField(max_length=50,null=True)
    business_name = models.CharField(unique=False, max_length=50)
    business_email = models.EmailField(unique=True,max_length=25,blank=False,default="")
    business_website = models.URLField(blank=True, max_length=50, default='')
    location_state = models.CharField(max_length=100, choices=state_choices, default="")
    administrator_first_name = models.CharField(max_length=50)
    administrator_last_name = models.CharField(max_length=50)
    administrator_job_title = models.CharField(blank=False,max_length=50,default="")
    phone_number = models.CharField(max_length=12, null=True,blank=True)
    action = models.CharField(max_length=100, choices=action_choices, default="")
    business_description = models.CharField(max_length=300, null=True,blank=True)
    admitted = models.BooleanField(default=False) 
    payment_details_set = models.BooleanField(default=False)


class Business_Payment_Detail(models.Model):
    business_profile = models.OneToOneField(Business_Profile,on_delete=models.CASCADE,default="")
    #bank_account_name = models.CharField(max_length=200, null=True)
    account_number = models.CharField(max_length=50,null=True)
    #subtype = models.CharField(max_length=200, null=True)
    #account_type = models.CharField(max_length=200, null=True)
    official_name = models.CharField(max_length=200, null=True)
    routing = models.CharField(max_length=50,null=True)
    #wire_routing= models.CharField(max_length=50,null=True)
    #mask = models.CharField(max_length=200, null=True)
    date_added = models.DateField(auto_now_add=True)
