#from twilio.rest import Client
#account_sid = 'ACd8b9a49645b9b292e25cc4fb9b6511a2'
#auth_token = '67f1b46e2d1048109f589f26b8038a38'

#def send_businessDetails(businessName,businessID, userPass):
    #client = Client(account_sid,auth_token)
    #message = client.messages.create(
        #body = f'You have successfully registered {businessName} on Ariaquickpay for Business. Your Business Id is: {businessID}. Password is: {userPass}. Login to your account with the link https://ariaquickpay.com/aria-for-business/login-business',
        #from_ = '+12055283966',
        #to = '+254791440121'
    #)

from django.core.mail import EmailMessage
from django.conf import settings


def send_business_registration_success_email(customer_email,businessName,businessID, userPass):
    email_subject = "Registration Successful"
    email_body = f"You have successfully registered {businessName} on Ariaquickpay for Business. Your Business Id is: {businessID}. Password is: {userPass}. Login to your account with the link https://ariaquickpay.com/aria-for-business/login-business"
    email=EmailMessage(subject=email_subject,body=email_body,from_email=settings.EMAIL_FROM_USER,
                    to=[customer_email])
    email.send()
