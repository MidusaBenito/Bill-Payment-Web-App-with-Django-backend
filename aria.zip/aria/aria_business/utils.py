import us 

def generateUsStates():
    state_choices = []
    
    for state in us.states.STATES:
        stateAbbr = state.abbr
        stateName = state.name
        #stateItem = "("+stateAbbr+","+stateName+")"
        choiceTuple = (stateAbbr,stateName)
        state_choices.append(choiceTuple)
    return state_choices