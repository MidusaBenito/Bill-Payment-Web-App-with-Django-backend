from django.urls import path
from unicodedata import name
#from django.contrib.auth import views as auth_views 
from . import views

urlpatterns = [
     path('',views.businessHomePage, name='business_home_page'),
     path('login-business/',views.businessLogin, name='business_login'),
     path('enroll/',views.businessRegisterPage, name='business_register_page'),
     path('dashboard/',views.businessDashboard, name='business_dashboard'),
     path('logout/',views.business_logout,name='business_logout'),
]