from django.shortcuts import render,get_object_or_404,redirect
from .forms import BusinessRegistrationForm,BankPaymentDetailsForm
from django.contrib.auth.models import User
from .password_generator import *
from .business_id_generator import *
from .send_business_details import *
from django.contrib.auth import authenticate,login,logout
from .models import *
from aria_users.models import User_Details
from aria_manual_billers.models import All_Manual_Billers
from aria_bill_processing_manual.models import Customer_Manual_Bill_Profile
from bill_settlement.models import *
import json
from django.http import JsonResponse 
from django.contrib.auth.decorators import login_required
from django.core.mail import EmailMessage

# Create your views here.
def businessHomePage(request):
    context = {}
    return render(request,'aria_business/business_home.html',context)

def businessRegisterPage(request):
    if request.method == "POST":
        form = BusinessRegistrationForm(request.POST)
        if form.is_valid():
            business_name = form.cleaned_data['business_name']
            business_email = form.cleaned_data['business_email']
            temporary_password = generate_Password()
            try:
                existing_business = User.objects.get(username=business_email)
                formError2 = f'A user with the email address {business_email} already exists! Try another email address'
                return render(request,'aria_business/business_register.html',{'form': form,'formError2':formError2})
            except User.DoesNotExist:
                new_business = User.objects.create_user(username=business_email,email=business_email,password=temporary_password)
                new_user = authenticate(username=business_email,password=temporary_password)
                account_type = get_object_or_404(User_Details,user=new_user)
                account_type.account_type = "Business"
                account_type.save()
                #new_user.account_type = "Business"
                #new_user.save()
                business_id = generate_business_id(business_name,new_user)
                business_website = form.cleaned_data['business_website']
                location_state = form.cleaned_data['location_state']
                administrator_first_name = form.cleaned_data['administrator_first_name']
                administrator_last_name = form.cleaned_data['administrator_last_name']
                administrator_job_title = form.cleaned_data['administrator_job_title']
                phone_number = form.cleaned_data['phone_number']
                action = form.cleaned_data['action']
                business_description = form.cleaned_data['business_description']
                #send_businessDetails(business_name,business_id,temporary_password)
                new_business_profile = Business_Profile.objects.create(user=new_user,phone_number=phone_number,business_website=business_website,business_email=business_email,business_name=business_name,business_id=business_id,location_state=location_state,administrator_first_name=administrator_first_name,administrator_last_name=administrator_last_name,administrator_job_title=administrator_job_title,action=action,business_description=business_description)
                #new_business = form.save()
                #send_businessDetails(business_name,business_id,temporary_password)
                send_business_registration_success_email(business_email,business_name,business_id, temporary_password)
                context = {"email":business_email}
                return render(request,'aria_business/details_received.html',context)
    else:
        form = BusinessRegistrationForm()
    context = {'form':form}
    return render(request,'aria_business/business_register.html',context)

@login_required
def businessDashboard(request):
    user = request.user
    user_detail = User_Details.objects.get(user=user)
    if user_detail.account_type == "Business":
        business_profile = Business_Profile.objects.get(user=user)
        if request.method == "POST":
            form = BankPaymentDetailsForm(request.POST)
            if form.is_valid():
                account_number = form.cleaned_data['account_number']
                official_name = form.cleaned_data['official_name']
                routing = form.cleaned_data['routing']
                if business_profile.payment_details_set == False:
                    business_payment_details = Business_Payment_Detail.objects.create(business_profile=business_profile,account_number=account_number,official_name=official_name,routing=routing)
                    business_profile.payment_details_set = True
                    business_profile.save()
                    context = {"business_profile":business_profile,"business_payment_details":business_payment_details}
                business_payment_details = Business_Payment_Detail.objects.get(business_profile=business_profile)
                if business_profile.payment_details_set == True:
                    business_payment_details.account_number = account_number
                    business_payment_details.official_name = official_name
                    business_payment_details.routing = routing
                    business_payment_details.save()
                    form = BankPaymentDetailsForm(instance=business_payment_details)
                    context = {"business_profile":business_profile,"business_payment_details":business_payment_details,"form":form}
                return render(request, 'aria_business/business_dashboard.html', context)
            #context = {"business_profile":business_profile,"form":form}
        else:
            form = BankPaymentDetailsForm()
            business_payment_details = ""
            business_customers_found = False
            business_customers = ''
            payments_made = False
            payments = ""
            try:
                business_bill = All_Manual_Billers.objects.get(business_profile=business_profile)
                
                try:
                    business_customers = Customer_Manual_Bill_Profile.objects.all().filter(all_manual_biller=business_bill)
                    business_customers_found = True
                except:
                    pass
            except:
                pass
            
            if business_profile.payment_details_set == True:
                business_payment_details = Business_Payment_Detail.objects.get(business_profile=business_profile)
                form = BankPaymentDetailsForm(instance=business_payment_details)
                
                try:
                    payments = Settled_Bill.objects.all().filter(recepient_account=business_payment_details)
                    if payments.count() > 0:
                        payments_made = True
                except:
                    pass
        context = {"business_profile":business_profile,"form":form,"business_payment_details":business_payment_details,"business_customers":business_customers,"business_customers_found":business_customers_found,"payments":payments,"payments_made":payments_made}
        return render(request, 'aria_business/business_dashboard.html', context)
    else:
        return redirect('home_page')


def businessLogin(request):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        businessID = data['businessID']
        userPass = data['userPass']
        message= ""
        print(businessID)
        print(userPass)
        try:
            #user_to_validate = User.objects.get(username='john')
            business_user = Business_Profile.objects.get(business_id=businessID)
            print(business_user)
            user_to_validate = business_user.user
            user = authenticate(request, username=user_to_validate.username, password=userPass)
            if user is not None:
                login(request, user)
                print("user authenticated")
                message = "valid BusinessID and Password!"
                data = {
                    'verdict':message
                        }
                #return redirect('business_dashboard')
                return JsonResponse(data,status=200)
            else:
                print("it's here")
                message = "Invalid BusinessID or Password!"

        except:
            print('nope, here!')
            message = "Invalid BusinessID or Password!"
        
        data = {
                    'verdict':message
                        }
                    
        print(data)
        return JsonResponse(data,status=200)

    context = {}
    return render(request, 'aria_business/business_login.html', context)



def business_logout(request):
    logout(request)
    return redirect('business_home_page')

def business_password_change(request):
    return redirect('business_login')