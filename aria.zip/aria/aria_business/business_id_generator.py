import datetime

def generate_business_id(name,user):
    name = name.upper()
    firstPart = name[0]
    numericPart = datetime.datetime.now().strftime('%M%S')+str(user.id)
    business_id = firstPart + numericPart
    print(business_id)
    return business_id

