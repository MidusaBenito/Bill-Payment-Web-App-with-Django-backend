from django.shortcuts import render, get_object_or_404, redirect
from .forms import ProfileEditForm
import json
from django.contrib.auth.decorators import login_required 
from django.http import JsonResponse 

# Create your views here.
from .models import *
from aria_manual_billers.models import *
from aria_users.models import User_Details

from notifications_center.views import updateCenter
from notifications_center.models import *

@login_required
def add_biller(request):
    customer = request.user
    categories = Biller_Category.objects.all().order_by("category_name")
    billers = All_Manual_Billers.objects.all().order_by("biller_name")
    mybills = {}
    
    client_profile = get_object_or_404(User_Details, user=customer)
    #biller_count = client_profile.customer_bill
    #print(biller_count.count())
    saved_billers = Customer_Manual_Bill_Profile.objects.all().filter(user_detail=client_profile)
    #saved_billers = Customer_Manual_Bill_Profile.objects.all()
    #form = ProfileEditForm
    
    #sort_bill_list = []
    for category in categories:
        billers_filtered = Biller_Category.objects.get(id=category.id).category.order_by("biller_name")
        if saved_billers.count() > 0:
            for saved_biller in saved_billers:
                if saved_biller.all_manual_biller in billers_filtered:
                    print(saved_biller.all_manual_biller)
                    billers_filtered = billers_filtered.exclude(biller_name = saved_biller.all_manual_biller)
                    print(saved_biller.all_manual_biller.biller_category)
        mybills[category] = billers_filtered[:6]
    

    if client_profile.profile_complete == False:
        return redirect('set-up')
    else:
        if request.headers.get("x-requested-with")== "XMLHttpRequest":
            data = json.loads(request.body)
            try:
                mess = data['item2Update']
                updateCenter(request,data)
            except:
                myaction = data['myaction']
                if myaction == 'add':
                    print("This is an ajax request!")
                    biller_id = data['biller_id']
                    print(biller_id)
                    biller = All_Manual_Billers.objects.get(id=biller_id)
                    customer_manual_bill_profile = Customer_Manual_Bill_Profile.objects.create(user_detail=client_profile,all_manual_biller=biller)
                    customer_manual_bill_profile.save()

                    #section for ajax data sent back to the template
                    assynch_cat = Biller_Category.objects.get(id=biller.biller_category.id).category_name
                    assynch_billers = All_Manual_Billers.objects.filter(biller_category=biller.biller_category.id)
                    saved_billers_assynch = Customer_Manual_Bill_Profile.objects.all().filter(user_detail=client_profile)
                    for my_saved_biller in saved_billers_assynch:
                        if my_saved_biller.all_manual_biller in assynch_billers:
                            #print(saved_biller.all_manual_biller)
                            assynch_billers = assynch_billers.exclude(biller_name = my_saved_biller.all_manual_biller)
                            #print(saved_biller.all_manual_biller.biller_category)
                    assynch_billers = assynch_billers[:6]
                    print(assynch_billers)
                    #assynch_billers = list(assynch_billers)
                    #print(assynch_billers)
                    refreshed_billers = {}
                    #adding image urls alonside ids to a dictionary instead of a list
                    biller_details = []
                    billerIds = []
                    for assynch_biller in assynch_billers:
                        #biller_details[assynch_biller.id] = assynch_biller.id
                        billerIds.append(assynch_biller.id)
                        try:
                            biller_details.append(assynch_biller.biller_logo.url) 
                        except:
                            biller_details.append('') 
                        print(biller_details)
                        refreshed_billers[assynch_biller.biller_name] = biller_details
                        biller_details = []
                    print(refreshed_billers)

                    
                    data = {
                        "biller_count": client_profile.customer_bill.count(),
                        "assynch_cat": assynch_cat,
                        "billerIds":billerIds,
                        "refreshed_billers":refreshed_billers
                    }

                if myaction == 'search':
                    #print("searching!!")
                    search_text = data['searchText']
                    search_cat = data['searchCat']
                    #results = All_Manual_Billers.objects.filter(biller_category=search_cat)
                    results = Biller_Category.objects.get(category_name=search_cat).category.order_by("biller_name")
                    presentBillers = Customer_Manual_Bill_Profile.objects.all().filter(user_detail=client_profile)
                    for presentBiller in presentBillers:
                        if presentBiller.all_manual_biller in results:
                            #print(saved_biller.all_manual_biller)
                            results = results.exclude(biller_name = presentBiller.all_manual_biller)
                    #results = results[:6]
                    #if results.count() > 0:
                    searchList = []
                    billerDict = {}
                    search_text = search_text.lower()
                    for result in results:
                        #print(result.biller_name)
                        if search_text == 'all':
                            billerDict['bId'] = result.id
                            billerDict['name'] = result.biller_name
                            try:
                                billerDict['image'] =  result.biller_logo.url
                            except:
                                billerDict['image'] = ''
                            searchList.append(billerDict)
                            billerDict = {}
                        else:
                            if search_text in result.biller_name.lower():
                                billerDict['bId'] = result.id
                                billerDict['name'] = result.biller_name
                                try:
                                    billerDict['image'] =  result.biller_logo.url
                                except:
                                    billerDict['image'] = ''
                                searchList.append(billerDict)
                                billerDict = {}
                    if len(searchList) > 0:
                        print(searchList)
                        searchList = searchList[:6]
                        verdict = 'true'
                        data = {
                            'verdict':verdict,
                            'searchList':searchList
                        }
                    else:
                        verdict = 'false'
                        data = {
                            'verdict':verdict
                        }
                    
                print(data)
                return JsonResponse(data,status=200)

    context = {"customer":customer,"categories":categories,"billers":billers,"mybills":mybills,"saved_billers":saved_billers}
    return render(request,"aria_bill_processing_manual/add.html",context)

@login_required
def set_up_profile(request):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    customer = request.user
    client_profile = get_object_or_404(User_Details, user=customer)
    #form = ProfileEditForm
    if request.method == "POST":
        form = ProfileEditForm(request.POST, instance=client_profile)
        if form.is_valid():
            new_profile = form.save(commit=False)
            client_profile.profile_complete = True
            new_profile.save()
            #context = {"customer":customer,"categories":categories,"billers":billers,"mybills":mybills}
            return redirect('add')
    else:
        form = ProfileEditForm(instance=client_profile)
    context = {"client_profile":client_profile,"form":form}
    return render(request,"aria_bill_processing_manual/profile_edit.html",context)
