from django.apps import AppConfig


class AriaBillProcessingManualConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aria_bill_processing_manual'
