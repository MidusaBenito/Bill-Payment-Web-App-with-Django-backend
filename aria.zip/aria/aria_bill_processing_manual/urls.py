from django.urls import path
from . import views

urlpatterns = [
    path("profile/set-up",views.set_up_profile,name="set-up"),
    path("profile/add",views.add_biller,name="add"),
]