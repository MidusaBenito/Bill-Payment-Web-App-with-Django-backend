from django.contrib import admin

from aria_bill_processing_manual.models import *

class PaymentDetailsInline(admin.StackedInline):
    model = PaymentDetails
    extra = 0
    fields = ['bill','month','last_name','first_name','paid','paid_amount','payment_method','transaction_id','date_paid']

class CustomerManualBillProfileAdmin(admin.ModelAdmin):
    inlines = [PaymentDetailsInline]
    list_display = ["user_name", "all_manual_biller","billing_frequency","next_due_date","date_added","billing_account_number","automatic_payments","send_email_reminder","due_date_set"]
    list_filter = ['user_detail__user', 'all_manual_biller']
    readonly_fields = ['user_name','all_manual_biller']
    #used the django lookup

    def user_name(self, obj):
        return obj.user_detail.user

admin.site.register(Customer_Manual_Bill_Profile,CustomerManualBillProfileAdmin)



#class PaymentDetailsAdmin(admin.ModelAdmin):
    #model = PaymentDetails
    #list_display = ['bill','month','paid','paid_amount','payment_method','date_paid']

#admin.site.register(PaymentDetails)
#@admin.register(Paid_Manual_Bill_Item)
#class PaidManualBillItemAdmin(admin.ModelAdmin):
    #list_display = ["user_detail", "all_manual_biller","billing_account_number","paid_amount"]
    #list_filter = ['user_detail', 'all_manual_biller']

