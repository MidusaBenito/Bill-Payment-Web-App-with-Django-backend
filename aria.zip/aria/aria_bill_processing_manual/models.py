from django.db import models
from django.utils import timezone
from django.urls import reverse 

from aria_users.models import User_Details
from aria_manual_billers.models import All_Manual_Billers

class Customer_Manual_Bill_Profile(models.Model):
    user_detail = models.ForeignKey(User_Details, related_name="customer_bill", on_delete=models.CASCADE, default="")
    all_manual_biller = models.ForeignKey(All_Manual_Billers,verbose_name="biller", related_name="user_biller", on_delete=models.CASCADE, default="")
    date_added = models.DateField(auto_now_add=True)
    next_due_date = models.DateField(blank=True,null=True)
    frequency_choices = [('Monthly','Monthly'),('Every 2 Months','Every 2 Months'),('Every 3 Months','Every 3 Months'),('Every 4 Months','Every 4 Months'),('Every 6 Months','Every 6 Months'),('Every 12 Months','Every 12 Months')]
    billing_frequency = models.CharField(max_length=20,choices=frequency_choices,default='Monthly')
    due_date_set = models.BooleanField(default=False)
    billing_account_number= models.CharField("Billing Account Number",max_length=20,null=True,default='')
    automatic_payments = models.BooleanField(default=False)
    send_email_reminder = models.BooleanField(default=False)
    #due_date = models.DateTimeField() #to be revesiteds
    class Meta:
        verbose_name = "Customer Bill Profile"
        verbose_name_plural = "Customer Bill Profiles"

    def __str__(self):
        return self.user_detail.user.username

    def get_absolute_url(self):
        return reverse('pay',
            args=[self.all_manual_biller.id, self.all_manual_biller.slug])

#class Month(models.Model)
class PaymentDetails(models.Model):
    month_choices = [('January','January'),('February','February'),('March','March'),('April','April'),('May','May'),('June','June'),('July','July'),('August','August'),('September','September'),('October','October'),('November','November'),('December','December')]
    payment_choices = [('Bank Account','Bank Account'),('Card','Card'),('Aria Wallet','Aria Wallet')]
    user_detail = models.ForeignKey(User_Details, related_name="customer_payments", on_delete=models.CASCADE, null=True)
    month = models.CharField(max_length=20, blank=True,choices=month_choices, default='January')
    bill = models.ForeignKey(Customer_Manual_Bill_Profile,related_name="bill_paid", on_delete=models.CASCADE, default="")
    #bill = models.CharField(max_length=20,default='')
    last_name = models.CharField(max_length=20,default='')
    first_name = models.CharField(max_length=20, default='')
    paid = models.BooleanField(default=False)
    paid_amount = models.DecimalField("Amount Paid", max_digits=6, decimal_places=2, default=0)
    payment_method = models.CharField(max_length=20,choices=payment_choices,default='Aria Wallet')
    transaction_id = models.CharField(max_length=25, blank=True, null=True)
    date_paid = models.DateField(default=timezone.now)

    def __str__(self):
        return self.bill.all_manual_biller.biller_name






