from django import forms
from django.forms import ModelForm
from aria_users.models import User_Details
#from phonenumber_field.widgets import  PhoneNumberPrefixWidget

#create a profile form
class ProfileEditForm(ModelForm):
    class Meta:
        model = User_Details
        fields = ("phone_number","customer_zip_code","time_zone")
        labels = {  "phone_number": "Mobile Number",
                    "customer_zip_code": "Zip Code",
                    "time_zone":"Time Zone:"
                    }
        widgets = {
            "phone_number": forms.TextInput(attrs={"class":"form-control","placeholder":"e.g 2025886500"}),
            #"phone_number": PhoneNumberPrefixWidget(initial="US",attrs={"class":"form-control","placeholder":"enter phone number in this format 2025886500"}),
            "customer_zip_code": forms.TextInput(attrs={"class":"form-control","placeholder":"enter zip code","required": "required"}),
            "time_zone":forms.Select(attrs={"class":"form-select form-select-sm"})
        }