document.addEventListener("DOMContentLoaded", function() {
    var headerCount = document.querySelectorAll('.accordion-header');
    var accHeader = document.querySelectorAll('.accordion-header').forEach(header => {
        header.addEventListener('click', event => {
            var clickedId = header.id;
            console.log(clickedId);
            let content = header.nextElementSibling;
            if (content.style.display=="none"){
                content.style.display="block";
                //add the class active
                header.classList.add("active");
                for(var i=0; i<headerCount.length; i++){
                    if (headerCount[i].classList.contains("active") && headerCount[i].id != clickedId){
                        header.classList.remove("active");
                        content.style.display = "none";
                    }
                    else{
                        content.style.display="block";
                    }
                }
            }
            else if (content.style.display="block"){
                content.style.display="none";
            }

        })
    });
});