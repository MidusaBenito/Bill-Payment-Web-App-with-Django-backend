from django.contrib import admin
from .models import *

# Register your models here.
def getFieldsModel(model):
    return [field.name for field in model._meta.get_fields()]


@admin.register(Settled_Bill)
class Business_Payment_DetailAdmin(admin.ModelAdmin):
    list_display = getFieldsModel(Settled_Bill)