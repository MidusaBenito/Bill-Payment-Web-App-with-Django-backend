from pickle import TRUE
from django.db import models
#from aria_manual_billers.models import All_Manual_Billers
from aria_bill_processing_manual.models import *
from aria_users.models import User_Details
from aria_business.models import Business_Payment_Detail

# Create your models here.

class Settled_Bill(models.Model):
    customer_manual_bill_profile = models.ForeignKey(Customer_Manual_Bill_Profile,related_name="bills_settled",on_delete=models.SET_NULL,null=True)
    user_detail = models.ForeignKey(User_Details, related_name="customer_settled_bill", on_delete=models.SET_NULL, null=True)
    recepient_account = models.ForeignKey(Business_Payment_Detail,related_name="business_account",on_delete=models.SET_NULL, null=True)
    paid_amount = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    date_added = models.DateTimeField(auto_now_add=True)