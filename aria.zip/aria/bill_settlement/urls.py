from django.urls import path
from django.contrib.auth import views as auth_views 
from . import views

urlpatterns = [
    path('', views.settled_bills_dashboard, name='settled_bills_dashboard'),
]