from pyexpat import model
from rest_framework.serializers import ModelSerializer
from rest_framework.authtoken.models import Token
from aria_bill_processing_manual.models import *
from aria_business.models import *
from aria_manual_billers.models import *
from aria_users.models import *
from bill_settlement.models import *
from notifications_center.models import *
from payments.models import *
from django.contrib.auth.models import User

class UserSerializer(ModelSerializer):
    class Meta:
        model = User
        fields = ['username','email','password']
        extra_kwargs = {'password': {"write_only": True, 'required': True}}

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        Token.objects.create(user=user)
        return user

class BillProfileSerializer(ModelSerializer):
    class Meta:
        model = Customer_Manual_Bill_Profile
        fields = '__all__'

