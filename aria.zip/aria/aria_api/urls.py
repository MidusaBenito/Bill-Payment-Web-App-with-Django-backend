from django.urls import path
from . import views
from rest_framework.authtoken.views import obtain_auth_token

urlpatterns = [
    path('login/',obtain_auth_token),
    path('register/',views.aria_api_register),
    #path('confirm-email-verification/<str:pk>/',views.getEmailVerificationStatus),
    path('bill-profile/',views.getMyBillers),
    path('add-biller/',views.AddBillers),
    path('get-verification-status/',views.getEmailVerificationandPk),
]