from .serializers import * 
from rest_framework.response import Response
from rest_framework import status 
#from rest_framework.authtoken.serializers import AuthTokenSerializer
from django.shortcuts import get_object_or_404

from rest_framework.decorators import api_view,authentication_classes,permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication




from aria_bill_processing_manual.models import *
from aria_business.models import *
from aria_manual_billers.models import *
from aria_users.models import *
from bill_settlement.models import *
from notifications_center.models import *
from payments.models import *
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str,DjangoUnicodeDecodeError
from django.conf import settings
from django.core.mail import EmailMessage
from aria_users.utils import generate_token
#from django.core import serializers


@api_view(['POST'])
def aria_api_register(request):
    serializers = UserSerializer(data=request.data)
    #print(request.data['username'])
    email = request.data['username']
    if serializers.is_valid():
        serializers.save()
        password = request.data['password']
        new_user = authenticate(username=email,password=password)
        send_activation_email(request,new_user)
        return Response({"error": "false","user_id":str(new_user.pk)})
    return Response({"error": "The email address " +str(email) + " is already registered","user_id":"null"})

#@api_view(['POST'])
#def aria_login(request):
    #serializer = AuthTokenSerializer(data=request.data)
    #serializer.is_valid(raise_exception=True)
   # user = serializer.validated_data['user']

    #_, token = AuthToken.objects.create(user)

    #return Response(
       # {
            #'user_info':{
               # 'id':user.id,
                #'email':user.email,
           # },
            #'token':token
        #}
    #)

#@api_view(['GET'])
#@authentication_classes([TokenAuthentication])
#@permission_classes([IsAuthenticated])
#def getEmailVerificationStatus(request):
    #try:
        #client = User.objects.get(pk=pk)
        #client_profile = get_object_or_404(User_Details, user=client)
        #if client_profile.is_email_verified:
            #return Response({"verified": "true","user_id":str(client.pk)})
        #else:
            #return Response({"verified": "false","user_id":str(client.pk)})
    #except:
        #return Response({"verified": "false"})

@api_view(['GET'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticated])
def getMyBillers(request):
    try:
        client = request.user
        print (client)
        client_profile = get_object_or_404(User_Details, user=client)
        customer_bill_profile = Customer_Manual_Bill_Profile.objects.all().filter(user_detail=client_profile)
        #serializer = BillProfileSerializer(customer_bill_profile,many=True)
        #return Response(serializer.data)
        billProfileList = []
        billItem = {}
        for bill in customer_bill_profile:
            billItem["biller_id"] = bill.all_manual_biller.id
            billItem["biller_name"] =  bill.all_manual_biller.biller_name
            try:
                billItem["biller_logo_url"] = bill.all_manual_biller.biller_logo.url
            except:
                billItem["biller_logo_url"] = "/media/no_Image.svg"
            billItem["biller_category"] = bill.all_manual_biller.biller_category.category_name
            billItem["due_date_set"] = bill.due_date_set
            if bill.due_date_set == True:
                billItem["next_due"] = bill.next_due_date
            else:
                billItem["next_due"] = "Not Set"
            billProfileList.append(billItem)
            billItem = {}
        print(billProfileList)
        #print("i remember")
        return Response(billProfileList)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

@api_view(['GET'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticated])
def AddBillers(request):
    client = request.user
    categories = Biller_Category.objects.all().order_by("category_name")
    billers = All_Manual_Billers.objects.all().order_by("biller_name")
    mybills = []
    cat_dict = {}
    biller_dict = {}
    biller_data = []
    bill_cat = []
    client_profile = get_object_or_404(User_Details, user=client)
    saved_billers = Customer_Manual_Bill_Profile.objects.all().filter(user_detail=client_profile)
    for category in categories:
        billers_filtered = Biller_Category.objects.get(id=category.id).category.order_by("biller_name")
        if saved_billers.count() > 0:
            for saved_biller in saved_billers:
                if saved_biller.all_manual_biller in billers_filtered:
                    billers_filtered = billers_filtered.exclude(biller_name = saved_biller.all_manual_biller)
        billers_filtered = billers_filtered[:6]
        
        for biller_filtered in billers_filtered:
            biller_data.append(biller_filtered.id)
            try:
                biller_data.append(biller_filtered.biller_logo.url)
            except:
                biller_data.append("/media/no_Image.svg")
            biller_dict[biller_filtered.biller_name] = biller_data
            biller_data = []
            bill_cat.append(biller_dict)
            biller_dict = {}
        cat_dict[category.category_name] = bill_cat
        bill_cat = []
        mybills.append(cat_dict)
        cat_dict = {}
            
    return Response(mybills)


@api_view(['POST'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticated])
def getEmailVerificationandPk(request):
    try:
        usermail = request.data['email']
        new_user = get_object_or_404(User,username=usermail)
        client_profile = get_object_or_404(User_Details, user=new_user)
        if client_profile.is_email_verified:
            return Response({"verified": "true","userPK":str(new_user.pk)})
        else:
            return Response({"verified": "false","userPK":str(new_user.pk)})

    except:
        return Response({"verified": "null","userPK":"null"})

#function to send activation email
def send_activation_email(request, user):
    current_site = get_current_site(request)
    email_subject = "Aria Account Email Verification"
    email_body = render_to_string('aria_users/activate.html',{
        'user':user,
        'domain':current_site,
        'uid':urlsafe_base64_encode(force_bytes(user.pk)),
        'token': generate_token.make_token(user)
            })
    email=EmailMessage(subject=email_subject,body=email_body,from_email=settings.EMAIL_FROM_USER,
                    to=[user.email])
    email.send()