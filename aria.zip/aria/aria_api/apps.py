from django.apps import AppConfig


class AriaApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aria_api'
