from django.shortcuts import render
from django.http import JsonResponse
import json
from .models import *
# Create your views here.
def updateCenter(request,data):
    
        try:
            mess = data['item2Update']
        except:
            mess="NULL"
        mydata = {
        "msg": "It worked!!",
        }
        print(mess)
        print('hello!!!')
        print(mydata)
        if mess == 'notifications':
            clearUnreadNotifications(request, mess)
        if mess == 'messages':
            clearUnreadMessages(request, mess)
        return JsonResponse(mydata)

def clearUnreadNotifications(request, messageAction):
    #action_complete = False
    if request.user.is_authenticated:
        if messageAction == 'notifications':
            my_notifications = Notifications.objects.all().filter(user=request.user,notificationRead=False)
            if my_notifications.count() > 0:
                for my_notification in my_notifications:
                    print(my_notification.notificationRead)
                    my_notification.notificationRead = True
                    my_notification.save()
                print("cleared all unread notifications!!")
                    #action_complete = True
        #return action_complete

def clearUnreadMessages(request, messageAction):
    #action_complete = False
    if request.user.is_authenticated:
        if messageAction == 'messages':
            my_messages = Messages.objects.all().filter(user=request.user,messageRead=False)
            if my_messages.count() > 0:
                for my_message in my_messages:
                    print(my_message.messageRead)
                    my_message.messageRead = True
                    my_message.save()
                print("cleared all unread messages!!")
