from django.contrib.auth.models import User
from django.db.models.signals import post_save, post_delete 
from django.dispatch import receiver 
#from aria_users.models import User_Details
from .models import *
from payments.models import Account
from aria_bill_processing_manual.models import *

@receiver(post_save, sender=User)
def create_welcome_message(sender,instance,created,**kwargs):
    if created:
        
        newMessage = f'Welcome to Ariaquickpay. An email was sent to your email at {instance.username}. Ensure that you verify your email to activate your account.'
        new_message = Messages.objects.create(user=instance,message_body=newMessage)
        new_message.save()


@receiver(post_save, sender=Account)
def create_link_bank_account_successful_notifications(sender,instance,created,**kwargs):
    if created:
        
        newNotification = f'You have successfully linked your {instance.name} account to Ariaquickpay. Paying your bills from your bank account will now be instant.'
        newNotification = Notifications.objects.create(user=instance.user_detail.user,notification_body=newNotification,notification_action= f'{instance.name} Bank Account Linked Successfully')
        newNotification.save()

@receiver(post_save, sender=Customer_Manual_Bill_Profile)
def create_bill_added_successfully_notifications(sender,instance,created,**kwargs):
    if created:
        
        newNotification = f'You have added {instance.all_manual_biller.biller_name} to your bill profile.'
        newNotification = Notifications.objects.create(user=instance.user_detail.user,notification_body=newNotification,notification_action= f'{instance.all_manual_biller.biller_name} Added Successfully to Biller Profile')
        newNotification.save()

@receiver(post_delete, sender=Customer_Manual_Bill_Profile)
def deleted_bill_successfully_notifications(sender,instance,*args,**kwargs):
    print('This is it')
    print(instance.all_manual_biller.biller_name)
    newNotification = f'You have deleted {instance.all_manual_biller.biller_name} from your bill profile.'
    newNotification = Notifications.objects.create(user=instance.user_detail.user,notification_body=newNotification,notification_action= f'{instance.all_manual_biller.biller_name} Removed Successfully from Biller Profile')
    newNotification.save()


@receiver(post_save, sender=PaymentDetails)
def create_payment_successful_messages(sender,instance,created,**kwargs):
    if created:
        print(instance)
        newMessage = f'Your {instance.bill.all_manual_biller.biller_name} bill has been successfully paid. Transaction Id is: {instance.transaction_id}'
        new_message = Messages.objects.create(user=instance.bill.user_detail.user,message_body=newMessage)
        new_message.save()
