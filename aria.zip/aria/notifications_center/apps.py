from django.apps import AppConfig


class NotificationsCenterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'notifications_center'

    def ready(self):
        import notifications_center.signals
