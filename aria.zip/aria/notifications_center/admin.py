from django.contrib import admin

from .models import *

@admin.register(Messages)
class MessagesAdmin(admin.ModelAdmin):
    list_display = ['user','message_body','messageRead','date_added']


@admin.register(Notifications)
class NotificationsAdmin(admin.ModelAdmin):
    list_display = ['user','notification_action','notification_body','notificationRead','date_added']