from django.db import models
#from aria_users.models import User_Details
from django.contrib.auth.models import User

class Notifications (models.Model):
    user = models.ForeignKey(User, null=True, on_delete=models.CASCADE)
    notification_action = models.CharField(max_length=50, null=True, blank=True)
    notification_body = models.CharField(max_length=300, null=True, blank=True)
    notificationRead = models.BooleanField(default=False)
    date_added = models.DateTimeField(auto_now_add=True, null=True)


class Messages (models.Model):
    user = models.ForeignKey(User, null=True, on_delete=models.CASCADE)
    message_body = models.CharField(max_length=300, null=True, blank=True)
    messageRead = models.BooleanField(default=False)
    date_added = models.DateTimeField(auto_now_add=True, null=True)



