from .models import *
from django.contrib.auth.decorators import login_required 
from django.http import JsonResponse
#from django.contrib.auth.models import User

#@login_required
def myMessages(request):
    if request.user.is_authenticated:
        my_messages = Messages.objects.all().filter(user=request.user).order_by('-date_added')
        unread_messages_count = 0
        
        if my_messages.count() > 0:
            for my_message in my_messages:
                if my_message.messageRead == False:
                    unread_messages_count += 1
        context = {'my_messages':my_messages,'unread_messages_count':unread_messages_count}
    else:
        context = {}
    return context


#@login_required
def myNotifications(request):
    if request.user.is_authenticated:
        my_notifications = Notifications.objects.all().filter(user=request.user).order_by('-date_added')
        unread_notifications_count = 0
        
        if my_notifications.count() > 0:
            for my_notification in my_notifications:
                if my_notification.notificationRead == False:
                    unread_notifications_count += 1
        context = {'my_notifications':my_notifications,'unread_notifications_count':unread_notifications_count}
        
    else:
        context = {}
    return context

