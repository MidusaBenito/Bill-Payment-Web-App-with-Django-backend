from unicodedata import name
from django.urls import path
from . import views

urlpatterns = [
            path('link-bank-account',views.linkBankAccount,name='link_bank'),
            path('create_link_token', views.create_link_token, name='create-link-token'),
            path('get_access_token', views.get_access_token, name='get-access-token'),
            #path('auth', views.get_auth, name="get-auth"),
            #path('balance', views.get_balance, name="get-balance"),
            path('pay/<int:id>/<slug:slug>',views.pay,name='pay'),
            path('pay/payment-successful/<int:id>',views.bank_charge_success,name='payment-successful'),
            path('webhooks/stripe',views.stripe_webhook,name='stripe-webhook'),
            #path('checkout',views.checkout,name='checkout'),
            path('success', views.success, name='success'),
            path('cancel', views.cancel, name='cancel')
            ]