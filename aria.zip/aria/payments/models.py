from django.db import models
#from django.utils import timezone
from aria_users.models import User_Details


# Create your models here.
class PlaidItem(models.Model):
    user_detail = models.ForeignKey(User_Details, related_name="customer_plaid", on_delete=models.CASCADE, default="")
    access_token = models.CharField(max_length=200, unique=True)
    item_id = models.CharField(max_length=200, unique=True)

    def __str__(self):
        return self.user_detail.user.username


class Account(models.Model):
    #id = models.AutoField(primary_key=True)
    user_detail = models.ForeignKey(User_Details, related_name="customer_plaid_account", on_delete=models.CASCADE, default="")
    item_id = models.ForeignKey(PlaidItem, on_delete=models.CASCADE, default=None, null=True, blank=True)
    plaid_account_id = models.CharField(max_length=200, null=True, unique=True)
    name = models.CharField(max_length=200, null=True)
    account_number = models.CharField(max_length=200,null=True,blank=True)
    subtype = models.CharField(max_length=200, null=True)
    account_type = models.CharField(max_length=200, null=True)
    official_name = models.CharField(max_length=200, null=True)
    available_balance = models.DecimalField("Available Balance", max_digits=6, decimal_places=2, default=0)
    current_balance = models.DecimalField("Current Balance", max_digits=6, decimal_places=2, default=0)
    routing = models.CharField(max_length=50,null=True)
    wire_routing= models.CharField(max_length=50,null=True)
    mask = models.CharField(max_length=200, null=True)
    date_added = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.official_name

class AriaWallet (models.Model):
    user_detail = models.ForeignKey(User_Details, related_name="customer_aria_wallet",null=True, on_delete=models.CASCADE)
    wallet_balance = models.DecimalField("Available Balance", max_digits=6, decimal_places=2, default=0)
    date_topped_up = models.DateField(auto_now=True)

    
