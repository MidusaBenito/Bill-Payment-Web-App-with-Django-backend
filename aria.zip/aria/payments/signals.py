#from django.contrib.auth.models import User
from django.db.models.signals import post_save 
from django.dispatch import receiver 
from aria_users.models import User_Details
from .models import AriaWallet

@receiver(post_save, sender=User_Details)
def create_aria_wallet(sender,instance,created,**kwargs):
    if created:
        #if instance.account_type == 'Personal':
        AriaWallet.objects.create(user_detail=instance)