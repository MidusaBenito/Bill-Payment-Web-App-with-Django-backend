import datetime
from locale import currency
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required 
#from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from .models import *
from django.contrib.auth.models import User
from aria_manual_billers.models import *
from aria_bill_processing_manual.models import *
from django.conf import settings 
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import EmailMessage
from django.db.models.functions import Extract
from decimal import Decimal
#from django.contrib.sites.shortcuts import get_current_site
#from django.template.loader import render_to_string
#from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
#from django.utils.encoding import force_bytes, force_str,DjangoUnicodeDecodeError
import plaid
from plaid.model.products import Products
from plaid.api import plaid_api
import json
import os
import stripe 
#from . import config
import random

from aria_users.utils import generate_token
from notifications_center.views import updateCenter
from notifications_center.models import *


#import ssl
#ssl._create_default_https_context = ssl._create_unverified_context
DOMAIN = 'http://localhost:8000'
stripe_id_event = ''

from plaid.model.link_token_create_request import LinkTokenCreateRequest
from plaid.model.link_token_create_request_user import LinkTokenCreateRequestUser
from plaid.model.item_public_token_exchange_request import ItemPublicTokenExchangeRequest
from plaid.model.auth_get_request import AuthGetRequest
from plaid.model.country_code import CountryCode
#from plaid.model.processor_stripe_token_create_request import ProcessorStripeBankAccountTokenCreateRequest
PLAID_PRODUCTS = os.getenv('PLAID_PRODUCTS', 'auth').split(',')
PLAID_COUNTRY_CODES = os.getenv('PLAID_COUNTRY_CODES', 'US').split(',')
PLAID_CLIENT_ID = os.getenv('PLAID_CLIENT_ID','6245d304a1f9250013235570')
PLAID_SECRET = os.getenv('PLAID_SECRET','4191417806995221b572849fb65fbe')

#stripe settings
stripe.api_key = settings.STRIPE_SECRET_KEY


configuration = plaid.Configuration(
    #host=plaid.Environment.Development,
    host=plaid.Environment.Development,
    api_key={
        'clientId': PLAID_CLIENT_ID,
        'secret': PLAID_SECRET,
        'plaidVersion': '2020-09-14'
    }
)
api_client = plaid.ApiClient(configuration)
plaidClient = plaid_api.PlaidApi(api_client)

#client = plaid.Client()

products_plaid = []
for product in PLAID_PRODUCTS:
    products_plaid.append(Products(product))
    
@login_required
def linkBankAccount(request):
    client = request.user
    client_profile = get_object_or_404(User_Details, user=client)
    bank_accounts = Account.objects.all().filter(user_detail=client_profile)
    if bank_accounts.count() == 0:
        return render (request,'payments/link_bank.html')
    else:
        if request.headers.get("x-requested-with")== "XMLHttpRequest":
            received = json.loads(request.body)
            try:
                mess = received['item2Update']
                updateCenter(request,received)
            except:
                #mess="NULL"
                
                item_id = received['item_id']
                accnt = received['bank']
                try:
                    account = Account.objects.get(account_number=accnt)
                    account.delete()
                    try:
                        item = PlaidItem.objects.get(id=item_id)
                        rem_accnts = Account.objects.all().filter(user_detail=client_profile,item_id=item)
                        if rem_accnts.count() == 0:
                            try:
                                #item = PlaidItem.objects.get(id=item_id)
                                item.delete()
                            except:
                                print('There is an error with deleting plaid item!!')
                    except:
                        print('something is wrong!!')
                except:
                    print("Deletion process not successful!!")
                refreshed_accnts = Account.objects.all().filter(user_detail=client_profile)
                data = {}
                if refreshed_accnts.count() > 0:
                    for refreshed_accnt in refreshed_accnts:
                        data['item_id'] = refreshed_accnt.item_id.id
                        data['account_number'] = refreshed_accnt.account_number
                        data['account_name'] = refreshed_accnt.name
                        data['available_balance'] = refreshed_accnt.available_balance
                    return JsonResponse(data, status=200)
                else:
                    return JsonResponse(data,status=200)
        context = {'bank_accounts':bank_accounts}
        return render(request,'payments/add_bank.html',context)
    

@login_required
def create_link_token(request):
    user = request.user
    data = LinkTokenCreateRequest(
        user = LinkTokenCreateRequestUser(
                client_user_id=str(user.id)
            ),
        client_name = 'Ariaquickpay',
        products = products_plaid,
        country_codes = list(map(lambda x: CountryCode(x), PLAID_COUNTRY_CODES)),
        language = 'en'
    )
    plaid_response = plaidClient.link_token_create(data)
    print(plaid_response)
    return JsonResponse(plaid_response.to_dict(),status=200)

@login_required
def get_access_token(request):
    client_profile = get_object_or_404(User_Details, user=request.user)
    body_data = json.loads(request.body)
    publicToken = body_data["publicToken"]
    exchange_request = ItemPublicTokenExchangeRequest(
            public_token=publicToken)
    exchange_response = plaidClient.item_public_token_exchange(exchange_request)
    access_token = exchange_response['access_token']
    item_id = exchange_response['item_id']
    authResponse = AuthGetRequest(access_token=access_token)
    auth_data = plaidClient.auth_get(authResponse)
    print(item_id)
    print(auth_data)
    accounts = auth_data['numbers']['ach']
    details = auth_data['accounts']
    user_plaid_item,created = PlaidItem.objects.get_or_create(user_detail=client_profile,access_token=access_token,item_id=item_id)
    user_plaid_item.save()
    for account in accounts:
        account_number = account['account']
        account_id = account['account_id']
        routing = account['routing']
        wire_routing = account['wire_routing']
        for detail in details:
            if detail['account_id'] == account_id:
                available = detail['balances']['available']
                current = detail['balances']['current']
                mask = detail['mask']
                name = detail['name']
                official_name = detail['official_name']
                subtype = detail['subtype']
                type = detail['type']
        #item_id = PlaidItem.objects.get()
        account_details,created = Account.objects.get_or_create(user_detail=client_profile,item_id=user_plaid_item,account_number=account_number,plaid_account_id=account_id,routing=routing,wire_routing=wire_routing,mask=mask,name=name,official_name=official_name,account_type=type,subtype=subtype,available_balance=available,current_balance=current)
        account_details.save()
    
    #return JsonResponse(auth_data.to_dict(),status=200)
    return redirect('link_bank')

@login_required
def pay(request,id,slug, control_int=0):
    client_profile = get_object_or_404(User_Details, user=request.user)
    bill = get_object_or_404(All_Manual_Billers, id=id, slug=slug)
    bank_accounts = Account.objects.all().filter(user_detail=client_profile)
    customer_bill_profile = get_object_or_404(Customer_Manual_Bill_Profile,user_detail=client_profile,all_manual_biller=bill)
    STRIPE_PUBLIC_KEY = settings.STRIPE_PUBLIC_KEY
    
    #variables for metadata webhook retrieval
    
    #print(bill.biller_category)
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        try:
            mess = data['item2Update']
            updateCenter(request,data)
            data = {'ok':'ok'}
            return JsonResponse(data,status=200)
        except:
            try:
                action = data['action']
            except:
                action = ''
            if action == 'submissions':
                due_date = customer_bill_profile
                if due_date.due_date_set == True:
                    date_set = 'true'
                    date_due = due_date.next_due_date
                else:
                    date_set = 'false'
                    date_due = 'Not Set'

                
                amount_payable = data['paid_amount']
                billingAccnt = data['acc_number']
                lastName = data['last_name']
                firstName = data['first_name']
                billName = bill.biller_name.upper()
                billCategory = bill.biller_category.category_name

                try:
                    billLogo = bill.biller_logo.url
                except:
                    billLogo = ''
                
                #cusbillingAccnt = billingAccnt
                #cuslastName = lastName
                #cusfirstName = firstName
                data = {
                    'amount':amount_payable,
                    'Accnt': billingAccnt,
                    'lastName': lastName,
                    'firstName': firstName,
                    'billName': billName,
                    'billCategory':billCategory,
                    'billLogo': billLogo,
                    'date_set':date_set,
                    'date_due':date_due
                }
                print(data)
                return JsonResponse(data,status=200)

            else:
                print(data)
                #adding stripe checkout session
                YOUR_DOMAIN = 'http://127.0.0.1:8000'
                name = data['billName']
                amount = float(data['amount'])* 100
                amount = int(amount)
                img = YOUR_DOMAIN + data['billLogo']
                bankAccnt = data['accNumber']
                first_name = data['lastName']
                last_name = data['firstName']
                billingAccnt = data['Accnt']
                
                print(img)
                if bankAccnt == 'card':
                    checkout_session = stripe.checkout.Session.create(
                        customer_email = request.user.email,
                        payment_method_types = ['card'],
                        #description = 'Paying from card',
                        line_items = [
                            {
                                'price_data': {
                                    'currency':'usd',
                                    'unit_amount': amount,
                                    'product_data': {
                                        'name': name,
                                        'images': [img]
                                    },
                                },
                                'quantity':1,
                            },
                        ],
                        metadata={
                        "email": request.user.email,
                        "product_id": bill.id,
                        "last_name":last_name,
                        "first_name":first_name,
                        "account_billed_to":billingAccnt,
                        "payment_method":"card",
                        "payment_type":"card_bill_pay",

                    },
                        mode = 'payment',
                        success_url =YOUR_DOMAIN + '/payments/success',
                        cancel_url = YOUR_DOMAIN + '/payments/cancel',
                    )

                    addBillToSession(request,bill.id)

                    return JsonResponse({
                        'id':checkout_session.id
                    })
                    #end of it
                
                else:
                    if bankAccnt == 'aria_wallet':
                        try:
                            user_wallet = AriaWallet.objects.get(user_detail=client_profile)
                            paid_amount = Decimal(data['amount'])
                            if user_wallet.wallet_balance > paid_amount:
                                payment_method = "Aria Wallet"
                                user_wallet.wallet_balance -= paid_amount
                                user_wallet.save()
                                biller = get_object_or_404(Customer_Manual_Bill_Profile,user_detail=client_profile,all_manual_biller=bill)
                                month= datetime.datetime.now()
                                month = month.strftime("%B")
                                print(month)
                                transaction_id =datetime.datetime.now().strftime('%d%H%M%S')+str(request.user.id)+str(bill.id)
                                print(transaction_id)
                                savePaymentDetails(month,biller,last_name,first_name,paid_amount,payment_method,transaction_id)
                                #send_payment_success_email(customer_email,biller.all_manual_biller.biller_name)
                            else:
                                print("insufficient wallet balance")
                                return JsonResponse(
                                    {'message':'Failed'}
                                )

                            return JsonResponse(
                                {'message':'Ok'}
                            )
                        except:
                            print("caught here")
                            return JsonResponse(
                                {'message':'Failed'}
                            )
                    else:
                        print(bankAccnt)
                        accountDetails = get_object_or_404(Account,account_number=bankAccnt,user_detail=client_profile)
                        customer = stripe.Customer.create(
                            email = request.user.email,
                            description='Paying from bank account'
                            )
                    
                        bank_token = stripe.Token.create(
                            bank_account = {
                                "country": "US",
                                "currency": "usd",
                                "account_holder_name": accountDetails.official_name,
                                "account_holder_type": "individual",
                                "routing_number": accountDetails.routing,
                                "account_number": accountDetails.account_number,
                            }
                        ) 
                        stripe.Customer.create_source(
                            customer.id,
                            source=bank_token.id,
                        )

                        bank_account = stripe.Customer.retrieve_source(
                            customer.id,
                            bank_token.bank_account.id,
                        )

                        bank_account.verify(amounts=[32, 45])
                        try:
                            charge = stripe.Charge.create(
                                amount = amount,
                                currency = 'usd',
                                customer = customer.id,
                                description="This bill has been paid through bank",
                                metadata={
                                "email": request.user.email,
                                "product_id": bill.id,
                                "last_name":last_name,
                                "first_name":first_name,
                                "account_billed_to":billingAccnt,
                                "payment_method":"bank",
                                "payment_type":"bank_bill_pay",
                            },
                                
                            )
                            
                            print(charge)
                            print(charge.id)
                            charge_result = charge['metadata']
                            #myresult = {'message':'Ok','charge_result':charge_result}

                            addBillToSession(request,bill.id)

                            return JsonResponse(
                                {'message':'Ok','details':charge_result}
                            )
                        except:
                            return JsonResponse({
                                'message':'Error with creating a charge'
                            })

                                      
    else:
        context = {'client_profile':client_profile,'bill':bill,'STRIPE_PUBLIC_KEY':STRIPE_PUBLIC_KEY,'bank_accounts':bank_accounts,'customer_bill_profile':customer_bill_profile}
        return render(request,'payments/pay.html',context)

#@login_required
#def checkout(request):
    #client_profile = get_object_or_404(User_Details, user=request.user)
    #bank_accounts = Account.objects.all().filter(user_detail=client_profile)
    
    #if request.headers.get("x-requested-with")== "XMLHttpRequest":
        #try:
           # mess = data['item2Update']
            #updateCenter(request,data)
        #except:
            #data = json.load(request)['paid_amount']
            #print(data)

    #this section is for stripe, to be continued
    
    #if request.method == 'POST':
        #checkout_session = stripe.checkout.Session.create(
            #line_items=[
               # {
                    #'price_data':{
                        #'currency':'usd',
                        #'unit_amount':2000,
                        #'product_data':{
                            #'name':'provide_name',
                            #'images':[''],
                        #},
                    #},
                    #'quantity':1,
                #},
            #],
            #mode='payment',
            #success_url=DOMAIN + '/success.html',
            #cancel_url=DOMAIN + '/cancel.html',
        #)
        
        #return JsonResponse({'id':checkout_session.id})
        #return redirect(checkout_session.url, code=303) 
    #else:
        #context = {'bank_accounts':bank_accounts}
        #return render (request,'payments/bank_charge_successful.html',context)

@login_required
def bank_charge_success(request,id):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    bill = get_object_or_404(All_Manual_Billers, id=id)
    request.session['testing'] = "This is the session!";
    if 'stripe_id_event' in request.session:
        stripe_id_event = request.session['stripe_id_event']
        print("i am printing the retrieved stripe event id")
        print(stripe_id_event)
        #if len(stripe_id_event) != 0:
        mybilldata = stripe.Event.retrieve(stripe_id_event)
        bill_id = mybilldata["data"]["object"]["metadata"]["product_id"]
        #bill = get_object_or_404(All_Manual_Billers, id=bill_id)
        first_name = mybilldata["data"]["object"]["metadata"]["first_name"]
        last_name = mybilldata["data"]["object"]["metadata"]["last_name"]
        email = mybilldata["data"]["object"]["metadata"]["email"]
        accountNo = mybilldata["data"]["object"]["metadata"]["account_billed_to"]
        bank_name = mybilldata["data"]["object"]["payment_method_details"]["ach_debit"]["bank_name"]
        context = { "bill":bill,
            "first_name":first_name,
                "last_name":last_name,
                "email":email,
                "accountNo":accountNo,
                "bank_name":bank_name
                }
    else:
        context = {"bill":bill}
    return render(request,'payments/bank_charge_success.html',context)


@csrf_exempt
def stripe_webhook(request):
    endpoint_secret = settings.STRIPE_WEBHOOK_SECRET
    payload = request.body
    sig_header = request.META['HTTP_STRIPE_SIGNATURE']
    event = None
    try:
        event = stripe.Webhook.construct_event(
        payload, sig_header, endpoint_secret
        )
    except ValueError as e:
        # Invalid payload
        return HttpResponse(status=400)
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        return HttpResponse(status=400)

  # Passed signature verification
    print(payload)
    if event['type'] == 'checkout.session.completed':
        print("this payment session involves the use of a card")
        session = event['data']['object']
        print(session)
        customer_email = session["customer_details"]["email"]
        user = get_object_or_404(User, username=customer_email)
        #database data to be saved
        payment_type = session["metadata"]["payment_type"]
        if payment_type == "card_bill_pay":
            product_id = session["metadata"]["product_id"]
            first_name = session["metadata"]["first_name"]
            last_name= session["metadata"]["last_name"]
            account_for_bill = session["metadata"]["account_billed_to"]
            paid_amount = session["amount_total"]
            paid_amount = paid_amount/100
            payment_method = 'Card'
            client_profile = get_object_or_404(User_Details, user=user)
            bill = get_object_or_404(All_Manual_Billers, id=product_id)
            biller = get_object_or_404(Customer_Manual_Bill_Profile,user_detail=client_profile,all_manual_biller=bill)
            billed_accnt = biller.billing_account_number
            if billed_accnt != account_for_bill:
                billed_accnt = account_for_bill
                billed_accnt.save()
            month= datetime.datetime.now()
            month = month.strftime("%B")
            print(month)
            transaction_id =datetime.datetime.now().strftime('%d%H%M%S')+str(user.id)+str(product_id)
            print(transaction_id)
            savePaymentDetails(month,biller,last_name,first_name,paid_amount,payment_method,transaction_id)
            send_payment_success_email(customer_email,biller.all_manual_biller.biller_name)
        if payment_type == "card_wallet_topup":
            print("topping up aria wallet via card payment!")
            user_detail = get_object_or_404(User_Details, user=user)
            balance = get_object_or_404(AriaWallet, user_detail=user_detail)
            print(balance.wallet_balance)
            balance.wallet_balance = float(balance.wallet_balance) + float(session["amount_total"]/100)
            balance.save()

    
    else:
        session = payload.decode('utf-8')
        session = json.loads(session)
        if session['type'] == 'charge.succeeded':
            try:
                payment_type = session["data"]["object"]["metadata"]["payment_type"]
            except:
                payment_type = ""
            if payment_type == "bank_bill_pay":
                print("this payment session involves bank transfer")
                customer_email = session["data"]["object"]["metadata"]["email"]
                user = get_object_or_404(User, username=customer_email)
                product_id = session["data"]["object"]["metadata"]["product_id"]
                
                #database data to be saved
                #payment_method = session["data"]["object"]["metadata"]["payment_method"]
                first_name = session["data"]["object"]["metadata"]["first_name"]
                last_name= session["data"]["object"]["metadata"]["last_name"]
                account_for_bill = session["data"]["object"]["metadata"]["account_billed_to"]
                paid_amount = session['data']['object']['amount']
                paid_amount = paid_amount/100
                payment_method = 'Bank Account'
                #end of it
                client_profile = get_object_or_404(User_Details, user=user)
                bill = get_object_or_404(All_Manual_Billers, id=product_id)
                biller = get_object_or_404(Customer_Manual_Bill_Profile,user_detail=client_profile,all_manual_biller=bill)
                billed_accnt = biller.billing_account_number
                if billed_accnt != account_for_bill:
                    biller.billing_account_number = account_for_bill
                    biller.save()
                month= datetime.datetime.now()
                month = month.strftime("%B")
                print(month)
                transaction_id = datetime.datetime.now().strftime('%d%H%M%S')+str(user.id)+str(product_id)
                print(transaction_id)
                savePaymentDetails(month,biller,last_name,first_name,paid_amount,payment_method,transaction_id)
                send_payment_success_email(customer_email,biller.all_manual_biller.biller_name)
                #return HttpResponse(status=200)
            if payment_type == "bank_wallet_topup": 
                print("topping up aria wallet via bank!") 
                customer_email = session["data"]["object"]["metadata"]["email"]
                user = get_object_or_404(User, username=customer_email)
                user_detail = get_object_or_404(User_Details, user=user)
                balance = get_object_or_404(AriaWallet, user_detail=user_detail)
                print(balance.wallet_balance)
                paid_amount = float(session['data']['object']['amount'])
                print(paid_amount)
                paid_amount = paid_amount/100
                balance.wallet_balance = float(balance.wallet_balance) + paid_amount
                balance.save()
    return HttpResponse(status=200)            
        

#@login_required
def success(request):
    #x = random.randint(100234677265,200234676465)
    context = {}
    if request.user.is_authenticated:
        user = request.user
        user_detail = get_object_or_404(User_Details,user=user)
        if request.session['bill_id']:
            bill_id = request.session['bill_id']
            try:
                payment = PaymentDetails.objects.all().filter(user_detail=user_detail).latest(id)
                if payment.bill.all_manual_biller.id == bill_id:
                    context = {'payment':payment}
            except:
                pass
    
    return render (request, 'payments/success.html', context)


#@login_required
def cancel(request):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    context = {}
    return render (request, 'payments/cancel.html', context)

def send_payment_success_email(customer_email,biller):
    email_subject = "Successful Bill Payment"
    email_body = f"Your {biller} bill payment was successful"
    email=EmailMessage(subject=email_subject,body=email_body,from_email=settings.EMAIL_FROM_USER,
                    to=[customer_email])
    email.send()


def savePaymentDetails(month,bill,last_name,first_name,paid_amount,payment_method,transaction_id):
    payment_details = PaymentDetails.objects.create(month=month,bill=bill,last_name=last_name,first_name=first_name,paid_amount=paid_amount,payment_method=payment_method,paid=True,transaction_id=transaction_id)
    payment_details.save()

def addBillToSession(request,bill_id):
    #transId = bill_id
    request.session['bill_id'] = bill_id






 


