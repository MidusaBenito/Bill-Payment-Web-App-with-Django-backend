from django.contrib import admin
from .models import *

# Register your models here.
@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    
    list_display = ['user_detail','item_id','plaid_account_id','name','account_number','subtype','account_type','official_name','available_balance','current_balance','routing','wire_routing','mask','date_added']
    

@admin.register(PlaidItem)
class PlaidItemAdmin(admin.ModelAdmin):
    list_display = ['user_detail','access_token','item_id']

@admin.register(AriaWallet)
class AriaWalletAdmin(admin.ModelAdmin):
    #def user_detail(self,obj):
        #return obj.user.email
    list_display = ['user_detail','wallet_balance','date_topped_up']


    
    


