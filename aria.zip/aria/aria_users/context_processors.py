from .forms import BillingForm
def mybilling_form(request):
    billing_form = BillingForm()
    context = {'billing_form':billing_form}
    return context

