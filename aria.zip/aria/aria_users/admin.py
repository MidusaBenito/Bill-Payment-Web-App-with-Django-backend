from django.contrib import admin

from .models import *

@admin.register(User_Details)
class UserDetailsAdmin(admin.ModelAdmin):
    #def first_name(self,user):
        #return user.user.first_name

    #def last_name(self,user):
        #return user.user.last_name

    list_display = ["user","customer_zip_code","phone_number","time_zone","account_type","is_email_verified","profile_complete"]
    list_filter = ["account_type"]


@admin.register(User_Feedback)
class User_Feedback(admin.ModelAdmin):
    

    list_display = ["user","name","email","message","date"]
    list_filter = ["user"]