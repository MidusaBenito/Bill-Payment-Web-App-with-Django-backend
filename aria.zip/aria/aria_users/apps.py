from django.apps import AppConfig


class AriaUsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aria_users'

    def ready(self):
        import aria_users.signals

