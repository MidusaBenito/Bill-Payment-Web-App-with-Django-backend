from django.db import models
from django.contrib.auth.models import User
from phonenumber_field.modelfields import PhoneNumberField
from django.utils import timezone


#class User(AbstractUser):
 #   is_email_verified = models.BooleanField(default=False)

  #  def __str__(self):
   #     return self.email


class User_Details(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    #first_name = models.OneToOneField("First Name",max_length=50)
    #last_name = models.CharField("Last Name",max_length=50)
    zone_choices = [("Hawaii","(GMT-10:00) Hawaii"),("Alaska","(GMT-09:00) Alaska"),("Pacific_Time","(GMT-08:00) Pacific Time (US & Canada)"),("Arizona","(GMT-07:00) Arizona"),("Mountain_Time","(GMT-07:00) Mountain Time (US & Canada)"),("Central_Time","(GMT-07:00) Mountain Time (US & Canada)"),("Eastern_Time","(GMT-05:00) Eastern_Time (US & Canada)"),("Indiana","(GMT-05:00) Indiana (East)")]
    customer_zip_code = models.CharField("Customer Zip Code", max_length=5)
    phone_number = PhoneNumberField(unique=False, max_length=12, blank=True, null=True)
    time_zone = models.CharField(max_length=100, choices=zone_choices, default="Mountain_Time")
    account_type = models.CharField(max_length=25,default="",null=True)
    is_email_verified = models.BooleanField(default=False) #field for showing whether a user's email is verified
    profile_complete = models.BooleanField(default=False)

    class Meta:
        #ordering= ("first_name", "last_name",)
        verbose_name="User Detail"
        verbose_name_plural = "User Details"
    #def __str__(self):
       #return self.user.username

def set_username(sender, instance, **kwargs):
    instance.username = instance.email
models.signals.pre_save.connect(set_username, sender=User)


class User_Feedback(models.Model):
    user = models.ForeignKey(User, null=True,on_delete=models.SET_NULL)
    name = models.CharField(max_length=50,default="",blank=False)
    email = models.EmailField(max_length=50,default="",blank=False)
    message = models.CharField(max_length=300,default="",blank=False)
    date = models.DateTimeField(default=timezone.now)
 