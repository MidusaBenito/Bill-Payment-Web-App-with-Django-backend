from django.urls import path
from django.contrib.auth import views as auth_views 
from . import views


urlpatterns = [
    path('',views.home_page, name='home_page'),
    path('create-account/', views.select_sign_up,name='select_sign_up'),
    path('signup/personal-account',views.sign_up,name='signup'),
    path('signup/business-account',views.sign_up_business,name='signup_business'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('payment-profile/', views.payment_settings, name='profile'),
    path('aria-wallet/',views.aria_wallet,name='aria_wallet'),
    path('bills-profile/',views.bills_profile,name='bills_profile'),
    path('calendar/',views.calendar,name='calendar'),
    path('activate-user/<uidb64>/<token>',views.activate_user,name='activate'),
    path('privacy-policy/',views.privacy_policy,name='privacy'),
    path('how-it-works/',views.how_it_works,name='how-it-works'),
    path('frequently-asked-questions/',views.faqs,name='faqs'),
    path('contact-us/',views.contact_us,name='contact_us'),
    #path('updateCenter/',views.updateNotifications,name="updateCenter"),
]