from pyexpat import model
from django import forms
from django.contrib.auth.forms import UserCreationForm
from . models import *
from aria_bill_processing_manual.models import *
from django.contrib.auth.models import User
#from phone_field import PhoneField


class SignUpForm(UserCreationForm):
    #password = forms.CharField(label='Password', widget=forms.PasswordInput)
    #password2 = forms.CharField(label='Confirm Password', widget=forms.PasswordInput)
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields["email"].widget.attrs.update({
            'required':'',
            'name':'email',
            'id':"exampleInputEmail1",
            "type":"email", 
            "class":"form-control",
            'placeholder':'Enter your email',
            'minlength':10,
            'maxlength':40

        })
        self.fields['password1'].widget.attrs.update({
            'required':'',
            'name':'password1',
            "type":"password",
            "class":"form-control",
            "id":"password1",
            'placeholder':'Enter your password',
            'minlength':8
        })
        self.fields['password2'].widget.attrs.update({
            'required':'',
            'name':'password2',
            "type":"password",
            "class":"form-control",
            "id":"password2",
            'placeholder':'Confirm your password',
            'minlength':8
        })
    class Meta:
        model = User
        fields = ['email','password1','password2']
        #labels = {"username":"Email address","password1":"Password","password2":"Confirm password"}
        #widgets = {"email":forms.EmailInput(attrs={"type":"email", "class":"form-control", "id":"exampleInputEmail1", "aria-describedby":"emailHelp"}),
                   #"password":forms.PasswordInput(attrs={"type":"password","class":"form-control","id":"exampleInputPassword1"})}
                   #"password2":forms.PasswordInput(attrs={"type":"password","class":"form-control","id":"exampleInputPassword2"})}

    #def clean_password2(self):
        #cd = self.cleaned_data
        #if cd['password1'] != cd['password2']:
            #raise forms.ValidationError("Passwords don't match.")
        #return cd['password2']
    #def clean(self):
        #super(SignUpForm, self).clean()
        #email = self.cleaned_data['email']
        #if User.objects.exclude(pk=self.instance.pk).filter(username=email).exists():
            #raise forms.ValidationError(f'The email address "{email}" is already in use.')
        #return email

class Form_Business(forms.ModelForm):

    class Meta:
        model = User_Details
        fields = ['phone_number','customer_zip_code','time_zone']
        labels = {  "phone_number": "Business Phone Number",
                    "customer_zip_code": "Zip Code",
                    "time_zone":"Time Zone"
                    }
        #zone_choices = [("Hawaii","(GMT-10:00) Hawaii"),("Alaska","(GMT-09:00) Alaska"),("Pacific_Time","(GMT-08:00) Pacific Time (US &amp; Canada)"),("Arizona","(GMT-07:00) Arizona"),("Mountain_Time","(GMT-07:00) Mountain Time (US &amp; Canada)"),("Central_Time","(GMT-07:00) Mountain Time (US &amp; Canada)"),("Eastern_Time","(GMT-05:00) Eastern_Time (US &amp; Canada)"),("Indiana","(GMT-05:00) Indiana (East)")]
        widgets = {
            "phone_number": forms.TextInput(attrs={"class":"form-control","placeholder":"e.g 2025886500"}),
            "customer_zip_code": forms.TextInput(attrs={"class":"form-control","placeholder":"enter zip code","required": "required"}),
            "time_zone":forms.Select(attrs={"class":"form-select form-select-sm"})
        }



class BillingForm(forms.ModelForm):
    class Meta:
        model = Customer_Manual_Bill_Profile
        fields = ("billing_account_number","billing_frequency","automatic_payments","send_email_reminder")
        labels = {  "billing_account_number":"Billing Account Number",
                    "billing_frequency": "Billing Frequency",
                    "automatic_payments": "Activate Automatic Payments for this Bill",
                    "send_email_reminder":"Send Me Email Reminders for this Bill"
                    }
        widgets = {
            "billing_account_number":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"Enter billing account number","style":"height:2rem;"}),
            "billing_frequency": forms.Select(attrs={"class":"form-select form-select-sm mt-1"}),
            "automatic_payments": forms.CheckboxInput(attrs={"class":"form-check-input","type":"checkbox", "value":"", "id":"flexCheckDefault","required": False}),
            "send_email_reminder":forms.CheckboxInput(attrs={"class":"form-check-input","type":"checkbox", "value":"", "id":"flexCheckDefault","required": False})
        }


class ContactUsForm(forms.ModelForm):
    class Meta:
        model = User_Feedback
        fields = ("name","email","message")
        labels = {
            "name": "Your Name",
            "email":"Your Email",
            "message":"Your Message"
        }
        widgets = {
            "name":forms.TextInput(attrs={"class":"form-control mt-1","type":"text","placeholder":"required","style":"height:2rem;"}),
            "email":forms.EmailInput(attrs={"type":"email", "class":"form-control", "placeholder":"required","style":"height:2rem;"}),
            "message":forms.Textarea(attrs={"class":"form-control mt-1","type":"text","rows":"3"}),
        }