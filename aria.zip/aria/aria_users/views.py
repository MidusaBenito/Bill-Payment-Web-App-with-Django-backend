from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required 
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str,DjangoUnicodeDecodeError
from django.core.mail import EmailMessage
from django.conf import settings
import json
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.contrib.auth import authenticate,login
from django.core import serializers
import stripe 
#
#import calendar
#from calendar import HTMLCalendar


from .models import *
from aria_bill_processing_manual.models import *
from payments.models import *
from .utils import generate_token
from .forms import SignUpForm,Form_Business,ContactUsForm
from dateutil import parser
from notifications_center.views import updateCenter
from notifications_center.models import *

from django.http import HttpResponseRedirect
from django.contrib import messages

#YOUR_DOMAIN = 'http://localhost:8000'
#YOUR_DOMAIN = 'https://ariaquickpay.com'
#stripe_id_event = ''
#stripe settings
stripe.api_key = settings.STRIPE_SECRET_KEY

#function to send activation email
def send_activation_email(request, user):
    current_site = get_current_site(request)
    email_subject = "Aria Account Email Verification"
    email_body = render_to_string('aria_users/activate.html',{
        'user':user,
        'domain':current_site,
        'uid':urlsafe_base64_encode(force_bytes(user.pk)),
        'token': generate_token.make_token(user)
            })
    email=EmailMessage(subject=email_subject,body=email_body,from_email=settings.EMAIL_FROM_USER,
                    to=[user.email])
    email.send()

#homepage view
def home_page(request):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    context = {}
    return render(request, 'aria_users/landing.html',context)

#signup view
def sign_up(request):
    if request.method == 'POST':
        signup_form = SignUpForm(request.POST)
            #zipcode_form = ZipCodeForm(request.POST)
        if signup_form.is_valid():
            email = signup_form.cleaned_data.get('email')
            password = signup_form.cleaned_data.get('password2')
            try:
                existing_user = User.objects.get(username=email)
                formError = f'A user with the email address {email} already exists! Try another email address'
                return render(request,'aria_users/sign_up.html',{'signup_form': signup_form,'formError':formError})
            except User.DoesNotExist:
                new_user = signup_form.save(commit=False)
                #new_user.set_password(signup_form.cleaned_data['password'])
                new_user.save()
                print('saved this file')
                new_user = authenticate(username=email,password=password)
                #if new_user is not None:
                #login(request,new_user)
                new_user.account_type = "Personal"
                new_user.save()
                client = new_user
                send_activation_email(request,new_user)
                #if new_user.save():
                #new_user_profile = zipcode_form.save(commit=False)
                #new_user_profile.save()
                return render(request, 'aria_users/email_verification.html',{'new_user': new_user, 'client':client})
        else:
            print('form not valid')
            print(signup_form.errors)
            return render(request, 'aria_users/sign_up.html',{'signup_form': signup_form})
    else:
        signup_form = SignUpForm()
            #zipcode_form = ZipCodeForm()
    return render(request, 'aria_users/sign_up.html',{'signup_form': signup_form})

def sign_up_business(request):
    if request.method == 'POST':
        signup_form = SignUpForm(request.POST)
        form_business = Form_Business(request.POST)
        if signup_form.is_valid() and form_business.is_valid():
            email = signup_form.cleaned_data.get('email')
            password = signup_form.cleaned_data.get('password2')
            try:
                existing_user = User.objects.get(username=email)
                formError = f'A user with the email address {email} already exists! Try another email address'
                return render(request,'aria_users/sign_up_business.html',{'signup_form': signup_form,'form_business':form_business,'formError':formError})
            except User.DoesNotExist:
                new_user = signup_form.save(commit=False)
                #new_user.set_password(signup_form.cleaned_data['password'])
                new_user.save()
                print('saved this file')
                new_user = authenticate(username=email,password=password)
                customer_zip_code = form_business.cleaned_data.get('customer_zip_code')
                phone_number = form_business.cleaned_data.get('phone_number')
                time_zone = form_business.cleaned_data.get('time_zone')
                new_profile = get_object_or_404(User_Details, user=new_user)
                new_profile.customer_zip_code = customer_zip_code
                new_profile.phone_number = phone_number
                new_profile.time_zone = time_zone
                new_profile.account_type = "Business"
                new_profile.profile_complete = True
                new_profile.save()

            #if new_user is not None:
                #login(request,new_user)
                client = new_user
                send_activation_email(request,new_user)
                return render(request, 'aria_users/email_verification.html',{'new_user': new_user, 'client':client})
        else:
            print('form not valid')
            print(signup_form.errors)
            return render(request, 'aria_users/sign_up_business.html',{'signup_form': signup_form,'form_business':form_business})

    else:
        signup_form = SignUpForm()
        form_business = Form_Business()
    return render(request, 'aria_users/sign_up_business.html',{'signup_form': signup_form,'form_business':form_business})
    

@login_required
def payment_settings(request):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    client = request.user
    client_profile = get_object_or_404(User_Details, user=client)
    if client_profile.is_email_verified:
        bank_accounts = Account.objects.all().filter(user_detail=client_profile).count()
        #bills_profile = Customer_Manual_Bill_Profile.objects.all().filter(user_detail=client_profile)
        total_paid = 0
        payment_data = {}
        bill_data = {}
        payment_details = PaymentDetails.objects.all()
        for payment_detail in payment_details:
            if payment_detail.bill.user_detail.user.username == client.username:
                #bill_data['transaction_id'] = payment_detail.transaction_id
                bill_data['date_paid'] = payment_detail.date_paid
                bill_data['paid_amount'] = payment_detail.paid_amount
                bill_data['biller'] = payment_detail.bill.all_manual_biller.biller_name
                total_paid += payment_detail.paid_amount
                payment_data[payment_detail.transaction_id] = bill_data
                bill_data = {}

        #payment_details = User
        print(payment_data)
        context = {'bank_accounts':bank_accounts,'client':client,'client_profile':client_profile,'payment_details':payment_data,'total_paid':total_paid}
        return render(request,'aria_users/payment.html',context)
    else:
        context = {'client':client,'client_profile':client_profile}
        return render(request,'aria_users/email_verification.html',context)

@login_required
def aria_wallet(request):
    #YOUR_DOMAIN = 'https://ariaquickpay.com'
    YOUR_DOMAIN = 'http://localhost:8000'
    client_profile = get_object_or_404(User_Details, user=request.user)
    STRIPE_PUBLIC_KEY = settings.STRIPE_PUBLIC_KEY
    if client_profile.is_email_verified:
        bank_accounts = Account.objects.all().filter(user_detail=client_profile).count()
        wallet_balance = get_object_or_404(AriaWallet, user_detail=client_profile).wallet_balance
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        try:
            checking = data['item2Update']
            if checking == 'notifications' or checking == 'messages':
                updateCenter(request,data)
        except:
            try:
                print('Wallet top up received by server!')
                walletAction = data['action']
                amount_payable = data['amount']
                amount_payable = float(amount_payable)*100
                amount_payable = int(amount_payable)
                print(amount_payable)
                print(walletAction)
                if walletAction == 'Card':
                    print('about to create a card session')
                    #print("Hey whatsup???")
                    checkout_session = stripe.checkout.Session.create(
                            customer_email = request.user.email,
                            payment_method_types = ['card'],
                            #description='Paid to Aria Wallet through Card',
                            line_items = [
                                {
                                    'price_data': {
                                        'currency':'usd',
                                        'unit_amount': amount_payable,
                                        'product_data': {
                                            'name': 'Aria Wallet Card Top Up',
                                            #'images': [img]
                                        },
                                    },
                                    'quantity':1,
                                },
                            ],
                            metadata={
                            "user_email": request.user.email,
                            #"last_name":last_name,
                            #"first_name":first_name,
                            #"account_billed_to":billingAccnt,
                            "payment_method":"card",
                            "payment_type":"card_wallet_topup",

                            },
                            mode = 'payment',
                            success_url =YOUR_DOMAIN + '/payments/success',
                            cancel_url = YOUR_DOMAIN + '/payments/cancel',
                        )
                    
                    print('session handled')
                    print(checkout_session.id)
                    return JsonResponse({
                        'id':checkout_session.id
                    })
                    
                if walletAction == 'Bank':
                    print("is a bank")
                    accountDetails = get_object_or_404(Account,subtype="checking",user_detail=client_profile)
                    #accountDetails = Account.objects.get(user_detail=client_profile,subtype=)
                    print(accountDetails)
                    print("This is happening")
                    customer = stripe.Customer.create(
                            email = request.user.email,
                            description='Paid to Aria Wallet through Bank',
                            )
                    print('This is happening')
                    print(customer)
                    bank_token = stripe.Token.create(
                            bank_account = {
                                "country": "US",
                                "currency": "usd",
                                "account_holder_name": accountDetails.official_name,
                                "account_holder_type": "individual",
                                "routing_number": accountDetails.routing,
                                "account_number": accountDetails.account_number,
                            }
                        ) 
                    stripe.Customer.create_source(
                            customer.id,
                            source=bank_token.id,
                        )

                    bank_account = stripe.Customer.retrieve_source(
                            customer.id,
                            bank_token.bank_account.id,
                        )

                    bank_account.verify(amounts=[32, 45])
                    try:
                        charge = stripe.Charge.create(
                                amount = amount_payable,
                                currency = 'usd',
                                customer = customer.id,
                                description="Aria Wallet has been topped-up through bank",
                                metadata={
                                "email": request.user.email,
                                #"product_id": bill.id,
                                #"last_name":last_name,
                                #"first_name":first_name,
                                #"account_billed_to":billingAccnt,
                                "payment_method":"bank",
                                "payment_type":"bank_wallet_topup",
                            },
                                
                            )
                            
                        print(charge)
                        print(charge.id)
                        charge_result = charge['metadata']
                            #myresult = {'message':'Ok','charge_result':charge_result}
                        return JsonResponse(
                                {'message':'Ok','details':charge_result}
                            )
                    except:
                        return JsonResponse({
                                'message':'Error with creating a charge'
                            })
            except:
                pass
    context = {'bank_accounts':bank_accounts,'STRIPE_PUBLIC_KEY':STRIPE_PUBLIC_KEY, "wallet_balance":wallet_balance}
    return render(request,'aria_users/aria_wallet.html',context)

@login_required
def bills_profile(request):
    
    client = request.user
    client_profile = get_object_or_404(User_Details, user=client)
    if client_profile.is_email_verified:
        customer_bill_profile = Customer_Manual_Bill_Profile.objects.all().filter(user_detail=client_profile)
        context = {'customer_bill_profile':customer_bill_profile,'client':client,'client_profile':client_profile}
        if request.headers.get("x-requested-with")== "XMLHttpRequest":
            data = json.loads(request.body)
            updateCenter(request,data)
            try:
                action_flag = data['delete_bill']
            except:
                action_flag = ""
            if action_flag == 'false':
                print('We have an ajax request!!')
                print(data)
                bill_id = data['bill_id']
                edited_bill = get_object_or_404(Customer_Manual_Bill_Profile,user_detail=client_profile,all_manual_biller_id=bill_id)
                print(edited_bill.all_manual_biller.biller_name)
                edited_bill.billing_frequency = data['billing_frequency']
                if data['automatic_payments'] == 'True':
                    auto_bool = True
                elif data['automatic_payments'] == 'False':
                    auto_bool = False
                
                if data['send_email_reminder'] == 'True':
                    reminder_bool = True
                elif data['send_email_reminder'] == 'False':
                    reminder_bool = False
                next_due = data['next_due']
                print(next_due)
                d = parser.parse(next_due).strftime("%Y-%m-%d")
                print(d)
                try:
                    billing_accnt_number = data['billing_accnt_number']
                except:
                    billing_accnt_number = ''
                edited_bill.next_due_date = d
                edited_bill.due_date_set = True
                edited_bill.automatic_payments = auto_bool
                edited_bill.send_email_reminder = reminder_bool
                edited_bill.billing_account_number = billing_accnt_number
                edited_bill.save()
                data = {
                    "next_due": get_object_or_404(Customer_Manual_Bill_Profile,user_detail=client_profile,all_manual_biller_id=bill_id).next_due_date
                }

            if action_flag == 'true':
                idBill = data['idBill']
                deleted_bill = get_object_or_404(Customer_Manual_Bill_Profile,user_detail=client_profile,all_manual_biller_id=idBill)
                deleted_bill.delete()
                customer_bill_profile = Customer_Manual_Bill_Profile.objects.all().filter(user_detail=client_profile)
                #billing_form = BillingForm()
                #customer_bill_profile = serializers.serialize("json",customer_bill_profile)
                #billing_form = serializers.serialize("json",billing_form)
                #data = {'customer_bill_profile':customer_bill_profile}
                #data = serializers.serialize("json",data)
                #print(data)
                data = {}
                myList = []
                details = {}
                for biller in customer_bill_profile:
                    billID = biller.all_manual_biller.id
                    details['name'] = biller.all_manual_biller.biller_name
                    try:
                        details['image_url'] = biller.all_manual_biller.biller_logo.url
                    except:
                        details['image_url'] = ''
                    try:
                        details['bill_link'] = biller.all_manual_biller.biller_url
                    except:
                        details['bill_link'] = ''
                    billcat = biller.all_manual_biller.biller_category.category_name
                    print(billcat)
                    details['category'] = billcat
                    details['due_date_set'] = biller.due_date_set
                    if biller.due_date_set == True:
                        details['next_due_date'] = biller.next_due_date
                    else:
                        details['next_due_date'] = 'nil';
                    details['pay'] = biller.get_absolute_url()
                    #details['id'] = billID
                    #myList.append(details)
                    data[billID] = details
                    details = {}
                myList.append(data)
                data = {'data':myList}
                print(data)
            return JsonResponse(data,status=200)
    return render(request,'aria_users/bills_profile.html',context)

@login_required
def calendar(request):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    context = {}
    return render(request,'aria_users/calendar.html',context)

def activate_user(request,uidb64,token):
    try:
        uid=force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
        client_profile = get_object_or_404(User_Details, user=user)
        print('Validly Executed!')
    except Exception as e:
        print('Error here!!')
        print(e)
        user=None

    if user and generate_token.check_token(user,token):
        client_profile.is_email_verified = True #come and check
        client_profile.save() # come and check
        return redirect('login')

def privacy_policy(request):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    return render(request,'aria_users/privacy.html')

def how_it_works(request):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    return render(request,'aria_users/how_it_works.html')

def select_sign_up(request):
    return render(request,'aria_users/select_sign_up.html')

def faqs(request):
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    return render(request,'aria_users/faqs.html')

def contact_us(request):
    if request.method == "POST":
        form = ContactUsForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            message = form.cleaned_data['message']
            if request.user.is_authenticated:
                new_user_feedback = User_Feedback.objects.create(user=request.user,name=name,email=email,message=message)
            else:
                new_user_feedback = User_Feedback.objects.create(name=name,email=email,message=message)
            #form = ContactUsForm()
            #message_submit = 'success'
            #context = {"form":form,"message_submit":message_submit}
            #return render(request,'aria_users/contact_us.html',context)
            messages.success(request, 'Your Message was Submitted Successfully!')
            return HttpResponseRedirect(request.path)

            #form.save()
    else:
        form = ContactUsForm()
    if request.headers.get("x-requested-with")== "XMLHttpRequest":
        data = json.loads(request.body)
        updateCenter(request,data)
    context = {"form":form}
    return render(request,'aria_users/contact_us.html',context)

#def updateNotifications(request):
    #updateCenter(request)
    #print("updating: it is working fine!!!")