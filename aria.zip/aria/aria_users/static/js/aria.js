/* Set the width of the side navigation to 250px and the left margin of the page content to 250px */
document.addEventListener("DOMContentLoaded", function() {

    toggleNav();
    showMob();
});

function toggleNav() {
        myToggler = document.getElementById("click_me");
        myToggler.addEventListener('click', function(){
            if (myToggler.classList.contains("active")){
                myToggler.classList.remove("active");
                document.getElementById("mySidenav").style.width = "0";
            }
            else{
                myToggler.classList.add("active");
                document.getElementById("mySidenav").style.width = "250px";
            }
        });
  }
  
  /* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    myToggler = document.getElementById("click_me");
    myToggler.classList.remove("active");
  }

  function showMob(){
      var mobuserbtn = document.querySelector('.mobuserbtn');
      var account_on_mobile = document.querySelector('.account_on_mobile');
      mobuserbtn.addEventListener('click', function(){
          if (account_on_mobile.style.display == "none"){
            account_on_mobile.style.display = "block";
          }
          else{
            account_on_mobile.style.display = "none";
          }
      });
  }
