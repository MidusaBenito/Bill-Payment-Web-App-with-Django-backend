document.addEventListener("DOMContentLoaded", function() {
    
    //updateNotifications();
    updateMessages();


});

function getMyToken(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

var csrftoken = getMyToken('csrftoken');

function updateMessages(){
    const mediaQuery = window.matchMedia('(max-width: 768px)');
    var messagesIcon = document.querySelector('.messo-desktop');
    if (mediaQuery.matches) {
        console.log("Its a mobile fon!!");
        var messagesIcon = document.querySelector('.messo-mobile');
    }
    
    var item2Update = 'messages';
    messagesIcon.addEventListener('click', function(){
    
        fetch("",{
            method:'POST',
            credentials:'same-origin',
            headers:{
                'Content-Type': 'application/json',
                'Accept':'application/json',
                'X-Requested-With':'XMLHttpRequest',
                'X-CSRFToken': csrftoken,
            },
            body: JSON.stringify({'item2Update':item2Update})
        }).then(
        response => {
            console.log(response.status);
            return response.status;

        }
        ).then(data => {
        console.log("received log");
        console.log(data);
            if (data == "200"){
                    document.querySelector('#messoDisplay').innerHTML = '0';
                    if (mediaQuery.matches){
                        document.querySelector('#messoMobDisplay').innerHTML = '0';
                    }
                   
               
                
            }
        })

    });
}