from django.contrib.auth.tokens import PasswordResetTokenGenerator
import six
from django.shortcuts import get_object_or_404
from .models import User_Details

class TokenGenerator(PasswordResetTokenGenerator):
    def _make_hash_value(self,user,timestamp):
        client_profile = get_object_or_404(User_Details, user=user)
        return (six.text_type(user.pk)+six.text_type(timestamp)+six.text_type(client_profile.is_email_verified)) #comeback and check

generate_token = TokenGenerator()