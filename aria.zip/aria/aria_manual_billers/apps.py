from django.apps import AppConfig


class AriaManualBillersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aria_manual_billers'
