from django.db import models
from aria_business.models import Business_Profile

#from aria_users.models import User_Details

class Biller_Category(models.Model):
    category_name=models.CharField("Category",max_length=50)
    slug = models.SlugField(max_length=50, unique=True, null=True, default='')

    class Meta:
        ordering = ('category_name',)
        verbose_name = 'Biller Category'
        verbose_name_plural = 'Biller Categories'

    def __str__(self):
        return self.category_name

    


class All_Manual_Billers(models.Model):
    biller_category = models.ForeignKey(Biller_Category, related_name="category",on_delete=models.CASCADE)
    business_profile = models.OneToOneField(Business_Profile,null=True,on_delete=models.SET_NULL)
    biller_name = models.CharField("Name of Biller",max_length=50)
    slug = models.SlugField(max_length=50, unique=True, default='')
    biller_logo = models.ImageField(blank=True) #remember this
    biller_url = models.URLField(blank=True, max_length=50, default='')

    class Meta:
        ordering = ('biller_name',)
        verbose_name = 'Name of Biller'
        verbose_name_plural = 'Name of Billers'

    def __str__(self):
        return self.biller_name

   

"""

    
"""


