from django.contrib import admin
from aria_manual_billers.models import *


@admin.register(Biller_Category)
class BillerCategoryAdmin(admin.ModelAdmin):
    list_display = ["category_name"]
    prepopulated_fields = {'slug': ('category_name',)}

@admin.register(All_Manual_Billers)
class AllManualBillersAdmin(admin.ModelAdmin):
    list_display = ["biller_name", "biller_category", "slug", "biller_logo","biller_url"]
    prepopulated_fields = {'slug': ('biller_name',)}
    list_filter = ["biller_category"]
